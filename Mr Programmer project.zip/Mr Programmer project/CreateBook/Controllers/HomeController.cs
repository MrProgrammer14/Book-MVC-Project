﻿using CreateBook.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CreateBook.Controllers
{
    public class HomeController : Controller
    {
        private static List<Book> books = new List<Book>
            {
                new Book
                {
                    Id = 1,
                    Name = "Sariq devni o`limi",
                    Author = "Xudoyberdi To`xtaboyev",
                    Price = 15000
                },
                new Book
                {
                    Id = 2,
                    Name = "O`tkan",
                    Author = "Qodiriy",
                    Price = 25000
                },
            };

        [HttpGet]
        public IActionResult Index()
        {
            return View(books);
        }
        public IActionResult Book()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Book request)
        {
            books.Add(request);
            return RedirectToAction("index");
        }
    }
}